package com.example.deepbreath;

import android.app.Activity;

public class SignupPatient extends Activity {
}
